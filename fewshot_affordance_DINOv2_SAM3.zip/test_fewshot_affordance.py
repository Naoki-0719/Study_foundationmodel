"""Synthetic end-to-end tests, no pretrained models/data/network needed."""
import argparse
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
import torch
from PIL import Image

from fewshot_affordance_common import (LABEL_COLORS, build_memory_bank, classify_knn,
                                       gt_to_feature_labels, load_gt, lookup_gt, run_experiment)
from fewshot_affordance_sam3 import SAM3Extractor


class FakeExtractor:
    def extract(self, img):
        # Fake feature map: RGB as a feature for tiny synthetic examples.
        x = np.asarray(img)
        vec = (x.astype(np.float32) / 255.0)
        bg = (x.sum(axis=2) == 0).astype(np.float32)[..., None]
        feat = torch.tensor(np.concatenate([vec, bg], axis=2)).permute(2, 0, 1)
        roi = np.ones(x.shape[:2], dtype=bool)
        return feat, roi


def test_main():
    with TemporaryDirectory() as t:
        root = Path(t)
        for part in ("support", "query"):
            (root / part / "MeasureData" / "2").mkdir(parents=True)
            (root / part / "Annotation" / "2").mkdir(parents=True)
        # support with 4 classes (background + 3 affordances)
        gt = np.array([[0, 1, 2, 3], [0, 1, 2, 3], [0, 1, 2, 3], [0, 1, 2, 3]], dtype=np.uint8)
        rgb = LABEL_COLORS[gt]
        for split in ("support", "query"):
            im_path = root / split / "MeasureData" / "2" / "sample.png"
            gt_path = root / split / "Annotation" / "2" / "sample.png"
            Image.fromarray(rgb).save(im_path)
            Image.fromarray(rgb).save(gt_path)
            assert lookup_gt(root / split / "Annotation", im_path,
                             root / split / "MeasureData") == gt_path
            assert np.array_equal(load_gt(gt_path, (4, 4)), gt)
        args = argparse.Namespace(
            support_image_dir=str(root / "support" / "MeasureData"),
            support_gt_dir=str(root / "support" / "Annotation"),
            image_dir=str(root / "query" / "MeasureData"),
            gt_dir=str(root / "query" / "Annotation"), shots=1, k=1, max_per_class=2000,
            seed=0, min_purity=0.5, chunk_size=4, output_dir=str(root / "out"),
            csv_out=None, bank_out=None, camera_type="", object_name="",
            num_objects=-1, prompt_id="", device="cpu",
        )
        run_experiment(args, FakeExtractor(), "fake")
        import csv
        with (root / "out" / "results.csv").open(encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == 7
        assert all(float(r["iou"]) == 1.0 for r in rows)
        assert (root / "out" / "2" / "sample_prediction.png").exists()
        bank = torch.load(root / "out" / "memory_bank.pt", weights_only=True)
        assert bank["features"].shape == (16, 4)
        assert set(bank["labels"].tolist()) == {0, 1, 2, 3}
        print("Synthetic end-to-end test passed")


def test_box():
    boxes = np.array([[3, 2, 7, 5]], dtype=np.float32)
    roi = SAM3Extractor.make_box_roi(boxes, 10, 10, padding=0.)
    assert roi.sum() == 12
    assert roi[2, 3] and not roi[5, 7]
    roi2 = SAM3Extractor.make_box_roi(np.zeros((0, 4)), 10, 10, padding=0.)
    assert roi2.all()
    print("SAM3 ROI test passed")


def test_knn():
    b = torch.tensor([[1., 0], [0, 1], [-1, 0]])
    y = torch.tensor([1, 2, 3])
    q = torch.tensor([[1., 0], [0, 1]])
    assert classify_knn(q, b, y, k=1, device="cpu", chunk_size=1).tolist() == [1, 2]
    assert classify_knn(q, b, y, k=2, device="cpu", chunk_size=1).tolist() == [1, 2]
    print("kNN tests passed")


def test_majority():
    gt = np.array([[1, 1, 2, 2], [1, 0, 2, 2],
                   [3, 3, 0, 0], [3, 3, 0, 0]], dtype=np.uint8)
    labels, purity = gt_to_feature_labels(gt, 2, 2)
    assert labels.tolist() == [[1, 2], [3, 0]]
    assert purity[0, 0] == 0.75
    print("GT majority test passed")


if __name__ == "__main__":
    test_main()
    test_box()
    test_knn()
    test_majority()


def test_wrappers_stubs():
    """Smoke test interfaces without downloading any model."""
    import sys
    import types
    from unittest.mock import patch
    from fewshot_affordance_dinov2 import DinoV2Extractor

    fake_trans = types.ModuleType('transformers')

    class FakeDinoModel(torch.nn.Module):
        config = types.SimpleNamespace(patch_size=2)
        @classmethod
        def from_pretrained(cls, path, local_files_only):
            assert local_files_only is True
            return cls()
        def forward(self, pixels):
            pooled = torch.nn.functional.avg_pool2d(pixels, kernel_size=2)
            tokens = pooled.flatten(2).transpose(1, 2)
            cls = torch.zeros((1, 1, tokens.shape[-1]), device=pixels.device)
            return types.SimpleNamespace(last_hidden_state=torch.cat([cls, tokens], dim=1))

    fake_trans.Dinov2Model = FakeDinoModel
    with TemporaryDirectory() as tmp, patch.dict(sys.modules, {'transformers': fake_trans}):
        model = DinoV2Extractor(tmp, 'cpu', 8)
        feats, roi = model.extract(Image.new('RGB', (10, 7), 'white'))
        assert feats.shape == (3, 4, 4) and roi.shape == (7, 10) and roi.all()
    print('DINOv2 feature-extraction wrapper test passed')

    model_builder = types.ModuleType('sam3.model_builder')
    proc_module = types.ModuleType('sam3.model.sam3_image_processor')
    fake_sam = types.ModuleType('sam3')
    fake_sub = types.ModuleType('sam3.model')

    def build_sam3_image_model(**kwargs):
        assert kwargs['load_from_HF'] is False
        assert kwargs['enable_inst_interactivity'] is False
        return object()

    class FakeProcessor:
        def __init__(self, model, **kwargs):
            self.device = kwargs['device']
        def set_image(self, image):
            return {'backbone_out': {'vision_features': torch.ones((1, 32, 5, 6))}}
        def set_text_prompt(self, state, prompt):
            assert prompt == 'box'
            return {'boxes': torch.tensor([[2., 2., 8., 6.]])}

    model_builder.build_sam3_image_model = build_sam3_image_model
    proc_module.Sam3Processor = FakeProcessor
    with TemporaryDirectory() as tmp:
        checkpoint = Path(tmp) / 'sam3.pt'
        checkpoint.touch()
        with patch.dict(sys.modules, {'sam3': fake_sam, 'sam3.model': fake_sub,
                                     'sam3.model_builder': model_builder,
                                     'sam3.model.sam3_image_processor': proc_module}):
            model = SAM3Extractor(str(checkpoint), None, 'cpu', 'box', 0.5, 0.1, 1008)
            feats, roi = model.extract(Image.new('RGB', (10, 10)))
            assert feats.shape == (32, 5, 6) and roi.shape == (10, 10)
            assert roi[2, 2] and not roi[0, 0]
            model2 = SAM3Extractor(str(checkpoint), None, 'cpu', 'box', 0.5, 0.1, 1008, True)
            _, roi2 = model2.extract(Image.new('RGB', (10, 10)))
            assert roi2.all()
    print('SAM3 feature/box extraction wrapper test passed')


if __name__ == '__main__':
    test_wrappers_stubs()
