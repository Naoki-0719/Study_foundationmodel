"""SAM3 image backbone + box-prompt ROI + class-labeled memory-bank k-NN.

SAM3 is only used to extract its PRE-prompt visual features and to detect a
box ROI using text prompt 'box'. It does not provide pixel-wise affordance labels.
No network downloads; checkpoint is loaded from local disk.
Example:
python fewshot_affordance_sam3.py \
    --checkpoint /models/sam3/sam3.pt \
    --support_image_dir DATA/support/MeasureData \
    --support_gt_dir DATA/support/Annotation \
    --image_dir DATA/query/MeasureData --gt_dir DATA/query/Annotation --shots 3
"""
import argparse
import os
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

import numpy as np
import torch
from PIL import Image

from fewshot_affordance_common import add_common_arguments, run_experiment


class SAM3Extractor:
    def __init__(self, checkpoint: str, bpe_path: str | None, device: str,
                 prompt: str, confidence: float, box_padding: float, resolution: int,
                 disable_box_roi: bool = False):
        from sam3.model_builder import build_sam3_image_model
        from sam3.model.sam3_image_processor import Sam3Processor

        if not Path(checkpoint).is_file():
            raise FileNotFoundError(f"SAM3チェックポイントがありません: {checkpoint}")
        if bpe_path is not None and not Path(bpe_path).is_file():
            raise FileNotFoundError(f"BPEファイルがありません: {bpe_path}")
        self.device = device
        self.prompt = prompt
        self.padding = box_padding
        self.disable_box_roi = disable_box_roi
        model = build_sam3_image_model(
            checkpoint_path=checkpoint, bpe_path=bpe_path, device=device,
            load_from_HF=False, enable_inst_interactivity=False,
        )
        self.processor = Sam3Processor(
            model, device=device, confidence_threshold=confidence, resolution=resolution
        )
        self.model = model

    @staticmethod
    def make_box_roi(boxes: np.ndarray, height: int, width: int, padding: float):
        roi = np.zeros((height, width), dtype=bool)
        if boxes.size == 0:
            print("[warning] SAM3で箱が検出できませんでした。画像全体をROIとして使用します", flush=True)
            roi[:] = True
            return roi
        for x0, y0, x1, y1 in boxes:
            bw, bh = max(1.0, x1 - x0), max(1.0, y1 - y0)
            left = max(0, int(np.floor(x0 - padding * bw)))
            top = max(0, int(np.floor(y0 - padding * bh)))
            right = min(width, int(np.ceil(x1 + padding * bw)))
            bottom = min(height, int(np.ceil(y1 + padding * bh)))
            if left < right and top < bottom:
                roi[top:bottom, left:right] = True
        if not roi.any():
            print("[warning] ROIが空です。画像全体を使用します", flush=True)
            roi[:] = True
        return roi

    @torch.inference_mode()
    def extract(self, image: Image.Image) -> tuple[torch.Tensor, np.ndarray]:
        state = self.processor.set_image(image)
        # Feature map is produced by vision encoder prior to applying 'box' prompt.
        fmap = state["backbone_out"]["vision_features"]
        if hasattr(fmap, "tensors"):
            fmap = fmap.tensors
        if not isinstance(fmap, torch.Tensor) or fmap.ndim != 4 or fmap.shape[0] != 1:
            raise ValueError(f"SAM3 image feature shape not supported: {type(fmap)}")
        if self.disable_box_roi:
            return fmap[0], np.ones((image.height, image.width), dtype=bool)
        # Query 'box' once, use resulting boxes; image encoding is cached in state.
        prompted = self.processor.set_text_prompt(state=state, prompt=self.prompt)
        boxes = prompted["boxes"]
        if isinstance(boxes, torch.Tensor):
            boxes = boxes.detach().cpu().numpy()
        boxes = np.asarray(boxes, dtype=np.float32).reshape(-1, 4)
        roi = self.make_box_roi(boxes, image.height, image.width, self.padding)
        return fmap[0], roi


def main():
    parser = argparse.ArgumentParser(description="SAM3 box ROI + few-shot kNN affordance segmentation")
    add_common_arguments(parser)
    parser.add_argument("--checkpoint", required=True, help="事前に用意したローカルSAM3 checkpoint (.pt)")
    parser.add_argument("--bpe_path", default=None, help="BPE語彙へのローカルパス（省略時はsam3付属）")
    parser.add_argument("--box_prompt", default="box")
    parser.add_argument("--box_confidence", type=float, default=0.5)
    parser.add_argument("--box_padding", type=float, default=0.10,
                        help="検出BBoxの縦横サイズに対する周囲の拡大量")
    parser.add_argument("--sam_resolution", type=int, default=1008)
    parser.add_argument("--disable_box_roi", action="store_true",
                        help="SAM3画像特徴のみを用い、箱ROIを使わないアブレーション")
    args = parser.parse_args()
    if not (0 <= args.box_confidence <= 1):
        parser.error("box_confidence must be between 0 and 1")
    if args.box_padding < 0 or args.sam_resolution <= 0:
        parser.error("box_padding must be nonnegative and resolution positive")
    extractor = SAM3Extractor(args.checkpoint, args.bpe_path, args.device,
                              args.box_prompt, args.box_confidence, args.box_padding,
                              args.sam_resolution, args.disable_box_roi)
    context = torch.autocast("cuda", dtype=torch.bfloat16) if args.device == "cuda" else torch.autocast("cpu", enabled=False)
    with torch.inference_mode(), context:
        run_experiment(args, extractor, method="sam3_box_memory_knn")


if __name__ == "__main__":
    main()
