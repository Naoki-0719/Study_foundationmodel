"""Shared memory-bank 1/5-shot affordance segmentation and evaluation.

Local-only inference. The repository and checkpoints must be installed locally.
No training/fine-tuning of foundation model is performed.
"""
from __future__ import annotations

import argparse
import csv
import os
from pathlib import Path
from typing import Optional

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".bmp", ".webp"}

# GT palette; everything not equal to one of these colors becomes background.
LABEL_NAMES = ("background", "grasp", "contain", "pick")
LABEL_COLORS = np.array(
    [(0, 0, 0), (255, 0, 0), (0, 0, 255), (0, 255, 0)], dtype=np.uint8
)
CSV_COLUMNS = (
    "method", "camera_type", "object_name", "num_objects", "prompt_id",
    "shots", "k", "image", "affordance", "iou", "gt_pixels", "pred_pixels",
)


def add_common_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--support_image_dir", required=True, help="教師側のMeasureData")
    parser.add_argument("--support_gt_dir", required=True, help="教師側のAnnotation")
    parser.add_argument("--image_dir", required=True, help="推論側のMeasureData（元コード準拠）")
    parser.add_argument("--gt_dir", default=None, help="推論側のAnnotation（省略すれば推論画像のみ）")
    parser.add_argument("--shots", type=int, default=1, choices=range(1, 6))
    parser.add_argument("--k", type=int, default=1, help="k-NN の k （1なら最近傍ラベル）")
    parser.add_argument("--max_per_class", type=int, default=2000, help="メモリバンクに残すクラス別特徴数。0は全数")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--min_purity", type=float, default=0.5, help="GTからのパッチラベル確信度の下限")
    parser.add_argument("--chunk_size", type=int, default=1024, help="類似度を計算するqueryパッチ数/回")
    parser.add_argument("--output_dir", default="fewshot_affordance_out")
    parser.add_argument("--csv_out", default=None, help="省略時は output_dir/results.csv")
    parser.add_argument("--bank_out", default=None, help="省略時は output_dir/memory_bank.pt")
    parser.add_argument("--camera_type", default="")
    parser.add_argument("--object_name", default="")
    parser.add_argument("--num_objects", type=int, default=-1)
    parser.add_argument("--prompt_id", default="")
    parser.add_argument("--device", choices=["cuda", "cpu"], default="cuda" if torch.cuda.is_available() else "cpu")


def validate_arguments(args: argparse.Namespace) -> None:
    if not (0 <= args.min_purity <= 1):
        raise ValueError("--min_purity は 0〜1 で指定してください")
    if args.k < 1 or args.chunk_size < 1 or args.max_per_class < 0:
        raise ValueError("--k, --chunk_size は正整数、--max_per_class は0以上です")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDAは使用できません。--device cpu を指定してください")
    for name in ("support_image_dir", "support_gt_dir", "image_dir"):
        path = Path(getattr(args, name))
        if not path.is_dir():
            raise FileNotFoundError(f"ディレクトリが見つかりません: {path}")
    if args.gt_dir is not None and not Path(args.gt_dir).is_dir():
        raise FileNotFoundError(f"ディレクトリが見つかりません: {args.gt_dir}")


def get_image_files(root: Path) -> list[Path]:
    """Subfolders (e.g., number-of-items folders) are handled recursively."""
    return sorted(p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTS)


def lookup_gt(root: Path, image_path: Path, image_root: Path) -> Optional[Path]:
    """Prefer matching relative directory+stem; fall back to unique stem."""
    rel = image_path.relative_to(image_root)
    local_dir = root / rel.parent
    if local_dir.is_dir():
        matches = sorted(p for p in local_dir.iterdir() if p.is_file() and
                         p.stem == rel.stem and p.suffix.lower() in IMAGE_EXTS)
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            raise ValueError(f"GTの候補が複数あります: {rel}")
    global_matches = [p for p in get_image_files(root) if p.stem == rel.stem]
    if len(global_matches) == 1:
        return global_matches[0]
    if len(global_matches) > 1:
        raise ValueError(f"GT名 '{rel.stem}' が複数のフォルダにあります。フォルダ構造を揃えてください")
    return None


def open_rgb(path: Path) -> Image.Image:
    with Image.open(path) as image:
        return image.convert("RGB")


def load_gt(path: Path, image_size: tuple[int, int]) -> np.ndarray:
    """GT image -> class IDs (H,W): 0=other/background, 1=red, 2=blue, 3=green."""
    with Image.open(path) as im:
        gt = im.convert("RGB")
        if gt.size != image_size:
            gt = gt.resize(image_size, resample=Image.Resampling.NEAREST)
        array = np.asarray(gt)
    labels = np.zeros(array.shape[:2], dtype=np.uint8)
    for cls in range(1, len(LABEL_NAMES)):
        labels[np.all(array == LABEL_COLORS[cls], axis=-1)] = cls
    return labels


def gt_to_feature_labels(gt: np.ndarray, h: int, w: int) -> tuple[torch.Tensor, torch.Tensor]:
    """Assign to each feature location the most frequent GT class in its pixel cell."""
    gt_tensor = torch.from_numpy(gt.astype(np.int64))
    onehot = F.one_hot(gt_tensor, num_classes=len(LABEL_NAMES)).permute(2, 0, 1).float().unsqueeze(0)
    freq = F.adaptive_avg_pool2d(onehot, (h, w))[0]
    purity, labels = freq.max(dim=0)
    return labels, purity


def roi_to_grid(roi: np.ndarray, h: int, w: int) -> torch.Tensor:
    # Area pooling makes sure that fine/thin ROI is not lost at the feature scale.
    array = torch.from_numpy(roi.astype(np.float32))[None, None]
    pooled = F.adaptive_max_pool2d(array, (h, w))[0, 0]
    return pooled > 0


def flatten_features(fmap: torch.Tensor) -> torch.Tensor:
    """Accept CHW map and return L2-normalized flattened matrix (H*W,C) on CPU."""
    if fmap.ndim != 3:
        raise ValueError(f"想定外の特徴マップサイズ: {tuple(fmap.shape)} (C,H,Wを期待)")
    features = fmap.float().permute(1, 2, 0).reshape(-1, fmap.shape[0])
    return F.normalize(features, dim=1).detach().cpu().contiguous()


def build_memory_bank(args, extractor, support_paths: list[Path], support_root: Path, support_gt_root: Path):
    features_by_class = {i: [] for i in range(len(LABEL_NAMES))}
    for i, image_path in enumerate(support_paths, 1):
        gt_path = lookup_gt(support_gt_root, image_path, support_root)
        if gt_path is None:
            raise FileNotFoundError(f"教師GTがありません: {image_path}")
        image = open_rgb(image_path)
        fmap, roi = extractor.extract(image)
        _, h, w = fmap.shape
        labels, purity = gt_to_feature_labels(load_gt(gt_path, image.size), h, w)
        inside = roi_to_grid(roi, h, w).reshape(-1)
        keep = inside & (purity.reshape(-1) >= args.min_purity)
        f = flatten_features(fmap)
        flat_labels = labels.reshape(-1)
        counts = {}
        for c in range(len(LABEL_NAMES)):
            selection = keep & (flat_labels == c)
            counts[LABEL_NAMES[c]] = int(selection.sum())
            if selection.any():
                features_by_class[c].append(f[selection])
        print(f"[support {i}/{len(support_paths)}] {image_path.relative_to(support_root)}: {counts}", flush=True)

    gen = torch.Generator().manual_seed(args.seed)
    bank_feats, bank_labels, counts = [], [], {}
    for c in range(len(LABEL_NAMES)):
        if not features_by_class[c]:
            counts[LABEL_NAMES[c]] = 0
            print(f"[warning] {LABEL_NAMES[c]} のメモリ特徴がありません", flush=True)
            continue
        feats = torch.cat(features_by_class[c], dim=0)
        if args.max_per_class > 0 and len(feats) > args.max_per_class:
            ids = torch.randperm(len(feats), generator=gen)[:args.max_per_class]
            feats = feats[ids]
        bank_feats.append(feats)
        bank_labels.append(torch.full((len(feats),), c, dtype=torch.long))
        counts[LABEL_NAMES[c]] = len(feats)
    if not bank_feats:
        raise ValueError("メモリバンクが空です。GT色、ROI、min_purityを確認してください")
    if sum(counts.values()) < args.k:
        raise ValueError(f"メモリ数 {sum(counts.values())} < k={args.k}")
    print(f"[bank] {counts}", flush=True)
    return torch.cat(bank_feats), torch.cat(bank_labels), counts


def classify_knn(query_feats: torch.Tensor, bank_feats: torch.Tensor, bank_labels: torch.Tensor,
                 k: int, device: str, chunk_size: int) -> torch.Tensor:
    """Cosine k-NN; k=1 takes nearest label; k>1 similarity-weighted voting."""
    # Only small chunks of query x bank similarity exist on the device at once.
    b = bank_feats.to(device)
    y = bank_labels.to(device)
    out = []
    for chunk in query_feats.split(chunk_size, dim=0):
        sims = chunk.to(device) @ b.T
        values, indices = sims.topk(k, dim=1)
        nearest_labels = y[indices]
        if k == 1:
            pred = nearest_labels[:, 0]
        else:
            # Positive cosine-based weights, avoiding negative votes.
            weights = ((values + 1) / 2).clamp(min=1e-6)
            votes = torch.zeros((chunk.shape[0], len(LABEL_NAMES)), device=device)
            votes.scatter_add_(1, nearest_labels, weights)
            pred = votes.argmax(dim=1)
        out.append(pred.cpu())
    return torch.cat(out)


def calculate_iou(pred: np.ndarray, gt: np.ndarray) -> float:
    union = np.logical_or(pred, gt).sum()
    return 1.0 if union == 0 else float(np.logical_and(pred, gt).sum() / union)


def save_visualizations(args, img: Image.Image, predicted: np.ndarray, rel: Path):
    output = Path(args.output_dir) / rel.parent
    output.mkdir(parents=True, exist_ok=True)
    stem = rel.stem
    rgb = LABEL_COLORS[predicted]
    Image.fromarray(rgb, mode="RGB").save(output / f"{stem}_prediction.png")
    src = np.asarray(img).astype(np.float32)
    overlay = src.copy()
    fg = predicted > 0
    overlay[fg] = src[fg] * 0.5 + rgb[fg].astype(np.float32) * 0.5
    Image.fromarray(overlay.astype(np.uint8), mode="RGB").save(output / f"{stem}_overlay.png")
    for class_id, name in enumerate(LABEL_NAMES[1:], 1):
        binary = ((predicted == class_id).astype(np.uint8) * 255)
        Image.fromarray(binary, mode="L").save(output / f"{stem}_{name}_mask.png")


def run_experiment(args: argparse.Namespace, extractor, method: str) -> None:
    validate_arguments(args)
    support_root, query_root = Path(args.support_image_dir), Path(args.image_dir)
    support_gt_root = Path(args.support_gt_dir)
    query_gt_root = Path(args.gt_dir) if args.gt_dir else None
    support_candidates = get_image_files(support_root)
    valid_support = [p for p in support_candidates if lookup_gt(support_gt_root, p, support_root) is not None]
    if len(valid_support) < args.shots:
        raise ValueError(f"教師GT付き画像が {len(valid_support)} 枚しかありません。shots={args.shots}")
    support_paths = valid_support[:args.shots]  # reproducible, sorted
    support_abs = {p.resolve() for p in support_paths}
    query_paths = [p for p in get_image_files(query_root) if p.resolve() not in support_abs]
    if not query_paths:
        raise ValueError("推論画像がありません（教師画像は重複防止のため除外しました）")
    if args.gt_dir:
        # GT may be in both dirs, but the support samples themselves must not be evaluated.
        query_gt_resolved = {lookup_gt(query_gt_root, p, query_root).resolve()
                             for p in query_paths if lookup_gt(query_gt_root, p, query_root) is not None}
        train_gt_resolved = {lookup_gt(support_gt_root, p, support_root).resolve() for p in support_paths}
        # If images differ but their GT path matches, this is suspicious; prevent leakage.
        if query_gt_resolved & train_gt_resolved:
            raise ValueError("教師と推論で同じGTファイルを参照しています。分割を確認してください")

    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    bank_feats, bank_labels, bank_counts = build_memory_bank(
        args, extractor, support_paths, support_root, support_gt_root
    )
    bank_path = Path(args.bank_out) if args.bank_out else outdir / "memory_bank.pt"
    bank_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save({
        "features": bank_feats, "labels": bank_labels,
        "label_names": LABEL_NAMES, "label_colors": LABEL_COLORS.tolist(),
        "method": method, "shots": args.shots, "selected_support_files": [str(p) for p in support_paths],
        "memory_counts": bank_counts,
    }, bank_path)
    print(f"[saved] memory bank: {bank_path}", flush=True)

    rows = []
    for index, path in enumerate(query_paths, 1):
        rel = path.relative_to(query_root)
        image = open_rgb(path)
        fmap, roi = extractor.extract(image)
        _, hf, wf = fmap.shape
        flat = flatten_features(fmap)
        pred_grid = classify_knn(flat, bank_feats, bank_labels, args.k, args.device, args.chunk_size)
        pred_grid = pred_grid.reshape(hf, wf).to(torch.uint8)
        # Nearest-neighbor upsampling preserves the discrete labels.
        pred = F.interpolate(pred_grid[None, None].float(), size=(image.height, image.width),
                             mode="nearest")[0, 0].to(torch.uint8).numpy()
        # Gate after interpolation at full pixel resolution.
        pred[~roi] = 0
        save_visualizations(args, image, pred, rel)

        gt_path = lookup_gt(query_gt_root, path, query_root) if query_gt_root else None
        if gt_path is None:
            print(f"[query {index}/{len(query_paths)}] {rel} (GTなし: 予測のみ)", flush=True)
            continue
        gt = load_gt(gt_path, image.size)
        scores = {}
        for class_id, name in enumerate(LABEL_NAMES[1:], start=1):
            mask = pred == class_id
            gt_mask = gt == class_id
            score = calculate_iou(mask, gt_mask)
            scores[name] = score
            rows.append({"method": method, "camera_type": args.camera_type,
                         "object_name": args.object_name, "num_objects": args.num_objects,
                         "prompt_id": args.prompt_id, "shots": args.shots, "k": args.k,
                         "image": str(rel), "affordance": name, "iou": score,
                         "gt_pixels": int(gt_mask.sum()), "pred_pixels": int(mask.sum())})
        print(f"[query {index}/{len(query_paths)}] {rel}: " +
              ", ".join(f"{n}={v:.4f}" for n, v in scores.items()), flush=True)

    if rows:
        for name in LABEL_NAMES[1:]:
            vals = [r["iou"] for r in rows if r["affordance"] == name]
            mean = float(np.mean(vals))
            print(f"[MEAN] {name}: {mean:.4f}", flush=True)
            rows.append({"method": method, "camera_type": args.camera_type,
                         "object_name": args.object_name, "num_objects": args.num_objects,
                         "prompt_id": args.prompt_id, "shots": args.shots, "k": args.k,
                         "image": "MEAN", "affordance": name, "iou": mean,
                         "gt_pixels": "", "pred_pixels": ""})
        all_mean = float(np.mean([r["iou"] for r in rows if r["image"] == "MEAN"]))
        rows.append({"method": method, "camera_type": args.camera_type,
                     "object_name": args.object_name, "num_objects": args.num_objects,
                     "prompt_id": args.prompt_id, "shots": args.shots, "k": args.k,
                     "image": "MEAN_ALL", "affordance": "ALL", "iou": all_mean,
                     "gt_pixels": "", "pred_pixels": ""})
        print(f"[MEAN_ALL] IoU={all_mean:.4f}", flush=True)
    else:
        print("[info] 評価用GTがないのでIoUは算出しませんでした", flush=True)

    csv_path = Path(args.csv_out) if args.csv_out else outdir / "results.csv"
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with csv_path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(rows)
    print(f"[saved] results: {csv_path}", flush=True)
