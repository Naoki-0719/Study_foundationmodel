# Few-shot Affordance Segmentation (DINOv2 / SAM3)

1〜5枚のカラーGT付き画像から **Memory Bank（特徴量＋機能ラベル）** を構築し、推論画像のパッチ特徴を **cosine k-NN** で分類する学習不要のベースラインです。`prompt.tsv` / `affordance_colors.tsv` は使用しません。

## ファイル

- `fewshot_affordance_common.py` : 教師GT読み込み、Memory Bank構築、k-NN、IoU評価、画像/CSV保存（**両版で必須**）
- `fewshot_affordance_dinov2.py` : DINOv2のパッチ特徴を使用（GTなしの推論も可）
- `fewshot_affordance_sam3.py` : SAM3のVision Backbone特徴を使用し、`box`検出BBox内を照合対象に設定
- `test_fewshot_affordance.py` : 人工データと疑似モデルによる動作確認（学習済みモデルは不要）

## GT

| ラベルID | 名前 | RGB値 |
|---|---|---|
| 0 | background | 赤/青/緑以外の画素 |
| 1 | grasp | (255,0,0) |
| 2 | contain | (0,0,255) |
| 3 | pick | (0,255,0) |

GT画像はPNG推奨。JPEGではRGB値がずれて正しく読めない場合があります。

## データ構成

教師側・推論側とも、従来の `MeasureData` / `Annotation` 構成を使用します。**下位の個数フォルダにも対応**します。

```text
DATA/
    MeasureData/
        1/001.png
        1/002.png
        2/003.png
    Annotation/
        1/001.png
        1/002.png
        2/003.png
```

**同じルートディレクトリを教師・推論の両方に指定することも可能**です。その場合、名前順の先頭 `--shots` 枚を教師に選び、**それらを推論・評価対象から除外**します。明示的な分割が必要なら教師・推論の各 `MeasureData/Annotation` を別々の場所に配置してください。

## 実行例：DINOv2

事前にローカルに保存した Hugging Face **Dinov2Model 形式**（例：`facebook/dinov2-base`）のディレクトリを指定します。公式torch.hub形式の `.pth` を直接読み込むスクリプトではありません。

```bash
python fewshot_affordance_dinov2.py \
  --model_dir /models/dinov2-base \
  --support_image_dir DATA/MeasureData \
  --support_gt_dir DATA/Annotation \
  --image_dir DATA/MeasureData \
  --gt_dir DATA/Annotation \
  --shots 3 \
  --k 1 \
  --output_dir out_dino
```

推論画像にGTがないときは `--gt_dir` を省略します（CSVはヘッダのみ）。

## 実行例：SAM3

元の `build_sam3_image_model` / `Sam3Processor` を使用します。`--checkpoint` はローカルに保存済みの `.pt` を指定してください。`bpe_simple_vocab_16e6.txt.gz` がインストール済みSAM3の `assets` 下にある場合は、`--bpe_path` を省略できます。

```bash
python fewshot_affordance_sam3.py \
  --checkpoint /models/sam3/sam3.pt \
  --support_image_dir DATA/MeasureData \
  --support_gt_dir DATA/Annotation \
  --image_dir DATA/MeasureData \
  --gt_dir DATA/Annotation \
  --shots 3 \
  --k 1 \
  --box_prompt box \
  --box_padding 0.10 \
  --output_dir out_sam3
```

SAM3が箱を検出できなかった場合、**警告を出して画像全体をROIに使用**します。SAM3の **特徴量そのものはプロンプト適用前のVision Backbone出力**です。`box` プロンプトはROI（Bounding Box）検出に使用しています。`--disable_box_roi`を付けるとROIなしのSAM3 Backbone特徴との比較もできます。

## 既定の特徴量照合

1. 特徴マップの空間解像度にGTを縮小して、各パッチに多数決ラベルを割り当てます（パッチ内の最大割合が `--min_purity=0.5` 以上）。
2. SAM3版ではサポート側・推論側ともに `box` BBoxの外側を除外（周囲10%を追加）。DINOv2版は全画面の特徴を利用。
3. クラスごとに最大 `--max_per_class=2000` 個をメモリバンクに保持（乱数seed固定）。`0`で全件保持。
4. 各推論位置についてL2正規化特徴をcosine類似度で検索。`--k 1`で最も近いラベル、`k>1`で類似度重み付き投票。
5. 結果を元画像解像度へ最近傍補間。SAM3版のBBox外側は背景に戻す。

**注意**：細い `grasp` 領域がパッチ内の多数決で失われる場合があります。まずMemory Bankの `grasp` 件数を確認し、必要ならラベル割当方法・特徴マップ解像度の改善が必要です。

## 保存結果

`--output_dir` 以下に、入力画像の相対サブフォルダを保ったまま以下を保存します。

- `{stem}_prediction.png`：赤／青／緑／黒のクラスIDカラー画像
- `{stem}_overlay.png`：RGB画像への半透明重ね合わせ
- `{stem}_grasp_mask.png`, `{stem}_contain_mask.png`, `{stem}_pick_mask.png`：各クラス二値マスク
- `memory_bank.pt`：L2正規化済み特徴・ラベル・教師画像ファイル一覧
- `results.csv`：各画像×3クラスのIoUと、クラス別平均・全クラス平均

両方空のIoUは元スクリプト同様に **1.0** として計算します。出力先を分けると両手法を比較できます。CSV中にIoUがない場合は、推論GTが見つからなかったことを意味します。

## オフライン実行・検証状況

- 画像とアノテーションを外部APIへ送る処理はありません。**モデル重みは事前に社内ポリシーで許可されたローカル環境に配備**してください。
- DINOv2版は `local_files_only=True` に固定、両版とも `HF_HUB_OFFLINE=1` および `TRANSFORMERS_OFFLINE=1` を設定しています。SAM3版は `load_from_HF=False` に固定しています。
- PyTorch、Pillow、NumPy、DINOv2版のみHugging Face `transformers`、SAM3版のみインストール済みの公式`sam3`実装が必要です。
- 構文チェック、人工GTでのMemory Bank / IoU計算、および疑似モデルによるDINOv2/SAM3取り出し処理テストは実施済み。**実モデルと機密画像の実行試験は未実施**です。

## 最初の比較実験

同じ教師画像を使い `--shots 1`, `3`, `5`、`--k 1` で比較すると、教師枚数の影響と基盤モデル差が見られます。なお標準設定のDINOv2版はROIを使わず、SAM3版はROIを使うので、これは**純粋なBackbone性能の比較ではありません**。SAM3版の `--disable_box_roi` でも実行して、ROIの効果を分けて検証してください。
