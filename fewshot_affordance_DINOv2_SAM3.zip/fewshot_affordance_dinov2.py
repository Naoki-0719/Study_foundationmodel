"""DINOv2 (local HF checkpoint) + class-labeled memory-bank k-NN.

No network downloads. GT: red=grasp, blue=contain, green=pick.
Example:
python fewshot_affordance_dinov2.py \
    --model_dir /models/dinov2-base \
    --support_image_dir DATA/support/MeasureData \
    --support_gt_dir DATA/support/Annotation \
    --image_dir DATA/query/MeasureData --gt_dir DATA/query/Annotation --shots 3
"""
import argparse
import os
from pathlib import Path

# Model loads MUST remain offline; input images are confidential.
os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TRANSFORMERS_OFFLINE"] = "1"
os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image

from fewshot_affordance_common import add_common_arguments, run_experiment


class DinoV2Extractor:
    def __init__(self, local_model_dir: str, device: str, input_size: int):
        # Imported here so --help and the test suite work without transformers.
        from transformers import Dinov2Model
        if not Path(local_model_dir).is_dir():
            raise FileNotFoundError(f"モデルフォルダがありません: {local_model_dir}")
        self.device = device
        self.size = input_size
        self.model = Dinov2Model.from_pretrained(local_model_dir, local_files_only=True)
        self.model.to(device).eval()
        self.patch_size = int(self.model.config.patch_size)
        if input_size % self.patch_size != 0:
            raise ValueError(f"DINOv2の入力解像度はpatch_size={self.patch_size}の倍数にしてください")
        self.mean = torch.tensor([0.485, 0.456, 0.406], device=device).view(1, 3, 1, 1)
        self.std = torch.tensor([0.229, 0.224, 0.225], device=device).view(1, 3, 1, 1)

    @torch.inference_mode()
    def extract(self, image: Image.Image) -> tuple[torch.Tensor, np.ndarray]:
        # Same squashed geometry as SAM3Processor; no center crop/offset.
        image_resized = image.resize((self.size, self.size), Image.Resampling.BICUBIC)
        pixel = torch.from_numpy(np.asarray(image_resized).copy()).to(
            device=self.device, dtype=torch.float32
        ).permute(2, 0, 1)[None] / 255.0
        pixel = (pixel - self.mean) / self.std
        # HF Dinov2Embeddings interpolates position embeddings automatically.
        output = self.model(pixel)
        tokens = output.last_hidden_state[:, 1:, :]  # remove CLS token
        h = w = self.size // self.patch_size
        if tokens.shape[1] != h * w:
            raise ValueError(f"DINOv2 token数が想定外: {tuple(tokens.shape)}")
        fmap = tokens.transpose(1, 2).reshape(1, -1, h, w)[0]
        roi = np.ones((image.height, image.width), dtype=bool)
        return fmap, roi


def main():
    parser = argparse.ArgumentParser(description="DINOv2 + few-shot kNN affordance segmentation")
    add_common_arguments(parser)
    parser.add_argument("--model_dir", required=True,
                        help="事前ダウンロード済みDINOv2のHugging Face形式checkpointディレクトリ")
    parser.add_argument("--input_size", type=int, default=518,
                        help="特徴抽出用正方形resize。DINOv2-baseでは14の倍数")
    args = parser.parse_args()
    if args.input_size <= 0:
        parser.error("input_size must be positive")
    extractor = DinoV2Extractor(args.model_dir, args.device, args.input_size)
    with torch.inference_mode():
        run_experiment(args, extractor, method="dinov2_memory_knn")


if __name__ == "__main__":
    main()
